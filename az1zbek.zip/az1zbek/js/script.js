const wrapper = document.querySelector('.wrapper');
const question = document.querySelector('.question');
const yesB = document.querySelector('.yes-b');
const noB = document.querySelector('.no-b');

const wrapperRect = wrapper.getBoundingClientRect();
const noBRect = noB.getBoundingClientRect();

yesB.addEventListener('click',() => {
 question.innerHTML = ' $10,000 from you :)';
});

noB.addEventListener('mouseover',() => {
 const i = Math.floor(Math.random() * (wrapperRect.width - noBRect.width)) + 1;
 const j = Math.floor(Math.random() * (wrapperRect.height - noBRect.height)) + 1;

 noB.style.left = i + 'px';
 noB.style.top = j + 'px';
});
